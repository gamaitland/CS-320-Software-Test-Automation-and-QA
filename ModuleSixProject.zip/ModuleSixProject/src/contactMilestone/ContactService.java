package contactMilestone;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

	private Map<String, Contact> ContactServiceMap;

	public ContactService() {
		this.ContactServiceMap = new HashMap<>();
	}
	
	//Adds new contact 
	public void addNewContact(Contact contact) {
		ContactServiceMap.put(contact.getId(), contact);
	}
	//Deletes a contact
	public void deleteContact(String id) {
		ContactServiceMap.remove(id);
	}
	//Updates first name
	public void updateFirstName(String id, String firstName) {
		Contact contact = ContactServiceMap.get(id);
		//If key does not exist in map, null is returned, so Check if null
		if (contact != null) {
			contact.setFirstName(firstName);
		}
	}
	
	//Updates last name
	public void updateLastName(String id, String lastName) {
		Contact contact = ContactServiceMap.get(id);
		if (contact != null) {
			contact.setLastName(lastName);
		}
	}
	//Updates phone number
	public void updatePhoneNumber(String id, String phoneNumber) {
		Contact contact = ContactServiceMap.get(id);
		if (contact != null) {
			contact.setPhoneNumber(phoneNumber);
		}
	}
	//Updates home address
	public void updateAddress(String id, String homeAddress) {
		Contact contact = ContactServiceMap.get(id);
		if (contact != null) {
			contact.setHomeAddress(homeAddress);
		}
	}
	

    public Contact getContact(String id) {
        return ContactServiceMap.get(id);
    }
	
}
	
	