package contactMilestone;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	//Checks if we are getting information back from object as intended
	void testContact() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		assertTrue(contact.getFirstName().equals("Johnny"));
		assertTrue(contact.getLastName().equals("Appleseed"));
		assertTrue(contact.getPhoneNumber().equals("5555555555"));
		assertTrue(contact.getHomeAddress().equals("123 Fake Street"));
		assertTrue(contact.getId().equals("1234567890"));
	}
	
	@Test
	//Checks if any of the entry fields for name, number, address, and id are empty fields
	void testContactEntryIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Appleseed", "5555555555", "123 Fake Street", "1234567890");
		});
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("Johnny", null, "5555555555", "123 Fake Street", "1234567890");
	     });
	     Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("Johnny", "Appleseed", "null", "123 Fake Street", "1234567890");
	     });
	     Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("Johnny", "Appleseed", "5555555555", null, "1234567890");
	     });
	     Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", null);
	     });
	}

	@Test
	//Checks if any of the entry fields for name, number, address, and id are too long (more than 10 chars)
	void testContactEntryTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Joohhnnnyyy", "Appleseed", "5555555555", "123 Fake Street", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnny", "Appleseeedd", "5555555555", "123 Fake Street", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnny", "Appleseed", "55555555556", "123 Fake Street", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnny", "Appleseed", "5555555555", "12345678910 Fakiest Fake Street", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "12345678910");
		});
	} 
	
	@Test
	//Checks if the phone number field is too short (less than 10 chars)
	void testContactNumberTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnny", "Appleseed", "555555555", "123 Fake Street", "1234567890");
		});
	}
	

	
}
