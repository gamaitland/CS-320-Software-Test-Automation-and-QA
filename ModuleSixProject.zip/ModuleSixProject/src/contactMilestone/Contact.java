package contactMilestone;

public class Contact {

	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String homeAddress;
	private String id;
	
	public Contact(String firstName, String lastName, String phoneNumber, String homeAddress, String id) {
		if (firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (phoneNumber == null || phoneNumber.length()>10 || phoneNumber.length()<10) {
			throw new IllegalArgumentException("Invalid number");
		}
		if (homeAddress == null || homeAddress.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		if (id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid id");
		}
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.homeAddress = homeAddress;
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public String getId() {
		return id;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	
}
