package contactMilestone;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;


import org.junit.jupiter.api.Test;

class ContactServiceTest {
	private ContactService contactService;
	
@BeforeEach
	public void preset() {
		contactService = new ContactService();
	}

	@Test
	 void testAddNewContact() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		
		Contact contactFound = contactService.getContact("1234567890");
		assertTrue(contactFound.getId().equals("1234567890"));
		assertTrue(contactFound.getFirstName().equals("Johnny"));
		assertTrue(contactFound.getLastName().equals("Appleseed"));
		assertTrue(contactFound.getPhoneNumber().equals("5555555555"));
		assertTrue(contactFound.getHomeAddress().equals("123 Fake Street"));

	}

	@Test
	void testDeleteContact() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		contactService.deleteContact("1234567890");
		Contact contactFound = contactService.getContact("1234567890");
		assertNull(contactFound);
	}	
	
	@Test
	void testUpdateFirstName() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		contactService.updateFirstName("1234567890", "Janet");
		Contact contactFound = contactService.getContact("1234567890");
		assertTrue(contactFound.getFirstName().equals("Janet"));

	}
	@Test
	void testUpdateLastName() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		contactService.updateLastName("1234567890", "Pumpkinseed");
		Contact contactFound = contactService.getContact("1234567890");
		assertTrue(contactFound.getLastName().equals("Pumpkinseed"));

	}
	@Test
	void testUpdatePhoneNumber() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		contactService.updatePhoneNumber("1234567890", "5554443322");
		Contact contactFound = contactService.getContact("1234567890");
		assertTrue(contactFound.getPhoneNumber().equals("5554443322"));

	}
	@Test
	void testUpdateHomeAddress() {
		Contact contact = new Contact("Johnny", "Appleseed", "5555555555", "123 Fake Street", "1234567890"); 
		contactService.addNewContact(contact);
		contactService.updateAddress("1234567890", "44 Faker Street");
		Contact contactFound = contactService.getContact("1234567890");
		assertTrue(contactFound.getHomeAddress().equals("44 Faker Street"));

	}
}
