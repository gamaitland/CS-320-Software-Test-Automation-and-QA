package appointmentMilestone;
import java.util.Date;

public class Appointment {
	
	private String id;
	private Date date;
	private String description;

	public Appointment(String id, Date date, String description) {
		if (id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Date");
		}
		
		if (description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.id = id;
		this.date = new Date(date.getTime());		
		this.description = description;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		if (id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		this.id = id;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Date");
		}
		this.date = date;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		if (description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}
}

