package appointmentMilestone;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	
	private Map<String, Appointment> AppointmentServiceMap;
	
	public AppointmentService() {
		this.AppointmentServiceMap = new HashMap<>();
	}
	
	//Adds new appointment
	public void addNewAppointment(Appointment appointment) {
		AppointmentServiceMap.put(appointment.getId(), appointment);
	}
	
	//Deletes Appointment
	public void deleteAppointment(String id) {
		AppointmentServiceMap.remove(id);
	}
	
	public Appointment getAppointment(String id) {
		return AppointmentServiceMap.get(id);
	}
}
