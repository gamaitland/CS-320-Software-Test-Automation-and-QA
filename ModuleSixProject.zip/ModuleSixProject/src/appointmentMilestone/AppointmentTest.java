package appointmentMilestone;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {
	
	@SuppressWarnings("deprecation")
	@Test
	//Checks if we are getting information back from object as intended
	void testAppointment() {
		Appointment appointment = new Appointment("1234567890", new Date(2023, 11, 25), "Go to hair salon");
		assertTrue(appointment.getId().equals("1234567890"));
		assertTrue(appointment.getDate().equals(new Date(2023, 11, 25)));
		assertTrue(appointment.getDescription().equals("Go to hair salon"));
	}
	
	@Test
	//Check for null entries
	void testAppointmentEntryIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, new Date(System.currentTimeMillis() + 1000000), "Go to hair salon");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", null, "Go to hair salon"); 
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(System.currentTimeMillis() + 1000000), null);
		}); 
	}
	
	@Test
	//Check for entries that are too long
	void testAppointmentEntryTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", new Date(System.currentTimeMillis() + 1000000), "Go to hair salon");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(System.currentTimeMillis() + 1000000), "Go to the hair salon and spend 5 hours there waiting to get your hair washed without any snacks.");
		});
	}
	
	@Test
	//Check to see if date parameter works
	void testAppointmentDateNotInPast() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(System.currentTimeMillis() - 1000000), "Go to hair salon");
		});
	}
}
