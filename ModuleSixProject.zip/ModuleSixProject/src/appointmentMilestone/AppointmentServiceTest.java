package appointmentMilestone;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

 class AppointmentServiceTest {
	 private AppointmentService appointmentService;
	 
	 @BeforeEach
	 public void preset() {
		 appointmentService = new AppointmentService();
	 }
	 
	 @SuppressWarnings("deprecation")
	@Test
	 void testAddNewAppointment() {
		 Appointment appointment = new Appointment("1234567890", new Date(2023, 11, 25), "Go to hair salon");
		 appointmentService.addNewAppointment(appointment);
		 
		 Appointment appointmentFound = appointmentService.getAppointment("1234567890");
		 assertTrue(appointmentFound.getId().equals("1234567890"));
		 assertTrue(appointmentFound.getDate().equals(new Date(2023, 11, 25)));
		 assertTrue(appointmentFound.getDescription().equals("Go to hair salon"));

	 }
	 
	 @SuppressWarnings("deprecation")
	@Test
	 void testDeleteAppointment() {
		 Appointment appointment = new Appointment("1234567890", new Date(2023, 11, 25), "Go to hair salon");
		 appointmentService.addNewAppointment(appointment);
		 appointmentService.deleteAppointment("1234567890");
		 Appointment appointmentFound = appointmentService.getAppointment("1234567890");
		 assertNull(appointmentFound);

	 }
 
}
