package taskServiceMilestone;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	//Checks if we are getting information back from object as intended
	void testTask() {
		Task task = new Task("Cleanup", "Clean apartment", "1234567890");
		assertTrue(task.getName().equals("Cleanup"));
		assertTrue(task.getDescription().equals("Clean apartment"));
		assertTrue(task.getId().equals("1234567890"));
}
	@Test
	//Checks for null entries
	void testTaskEntryIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Clean apartment", "1234567890");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("Cleanup", null, "1234567890");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("Cleanup", "Clean apartment", null);
			});
	}
	
	@Test
	//Check for entries that are too long
	void testTaskEntryTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("The cleanup song from Barney", "Clean apartment", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Cleanup", "Cleanup, cleanup, everybody everywhere. Cleanup, cleanup, everybody do your share!", "1234567890");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Cleanup", "Clean apartment", "123456789101112131415");
		});
	}
}
 