package taskServiceMilestone;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	private TaskService taskService;
	
@BeforeEach
	public void preset() {
		taskService = new TaskService();
	}

	@Test
	void testAddNewTask() {
		Task task = new Task("Cleanup", "Clean apartment", "1234567890");
		taskService.addNewTask(task);
		
		Task taskFound = taskService.getTask("1234567890");
		assertTrue(taskFound.getId().equals("1234567890"));
		assertTrue(taskFound.getName().equals("Cleanup"));
		assertTrue(taskFound.getDescription().equals("Clean apartment"));
	}
	
	@Test
	void testDeleteTask() {
		Task task = new Task("Cleanup", "Clean apartment", "1234567890");
		taskService.addNewTask(task);
		taskService.deleteTask("1234567890");
		Task taskFound = taskService.getTask("1234567890");
		assertNull(taskFound);
	}

	@Test
	void testUpdateName() {
		Task task = new Task("Cleanup", "Clean apartment", "1234567890");
		taskService.addNewTask(task);
		taskService.updateName("1234567890", "Make a mess");
		Task taskFound = taskService.getTask("1234567890");
		assertTrue(taskFound.getName().equals("Make a mess"));
	}
	
	@Test
	void testUpdateDescription() {
		Task task = new Task("Cleanup", "Clean apartment", "1234567890");
		taskService.addNewTask(task);
		taskService.updateDescription("1234567890", "Leave dirty laundry out");
		Task taskFound = taskService.getTask("1234567890");
		assertTrue(taskFound.getDescription().equals("Leave dirty laundry out"));
	}
} 
