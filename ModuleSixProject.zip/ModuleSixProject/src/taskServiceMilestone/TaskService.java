package taskServiceMilestone;

import java.util.HashMap;
import java.util.Map;


public class TaskService {
	
	private Map<String, Task> TaskServiceMap;
	
	public TaskService() {
		this.TaskServiceMap = new HashMap<>();
	}
	
	//Adds new task
	public void addNewTask(Task task) {
		TaskServiceMap.put(task.getId(), task);
	}
	
	//Deletes task
	public void deleteTask(String id) {
		TaskServiceMap.remove(id);
	}
	
	//Updates name
	public void updateName(String id, String name) {
		Task task = TaskServiceMap.get(id);
		//If key does not exist in map, null is returned so check for null
		if (task != null) {
			task.setName(name);
		}
	}
	
	//Updates Description
	public void updateDescription(String id, String description) {
		Task task = TaskServiceMap.get(id);
		if (task != null) {
			task.setDescription(description);
		}
	}

	
    public Task getTask(String id) {
        return TaskServiceMap.get(id);
    }
}



