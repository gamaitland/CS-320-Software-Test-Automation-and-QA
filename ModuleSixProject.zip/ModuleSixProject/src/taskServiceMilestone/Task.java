package taskServiceMilestone;

public class Task {

	
	private String name;
	private String description;
	private String id;
	
	public Task(String name, String description, String id) {
	
	if (name == null || name.length()>20) {
		throw new IllegalArgumentException("Invalid Name");
	}
	
	if (description == null || description.length()>50) {
		throw new IllegalArgumentException("Invalid description");
	}
	
	if (id == null || id.length()>20) {
		throw new IllegalArgumentException("Invalid ID");
	}

	
	this.name = name;
	this.description = description;
	this.id = id;

}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getId() {
		return id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setId(String id) {
		this.id = id;
	}
}